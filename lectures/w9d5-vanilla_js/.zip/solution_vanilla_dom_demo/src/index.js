// .5 
    // File structure
// 1
    // Talk about local storage
        // stores data in the browser for later use. No expiration date 
        // WAIT FOR QUESTION ON THIS
        // Not a cookie
            // Cookies are to be read server-side, localstorage is only client side
    // Demo:
        // check out local storage
        // clear localstorage if anything in it
        // localStorage.setItem(key,val)
// 2 
    // IN CONSOLE
    // Grab grocery form
        // grab first child
        // modify input
        // modify p[laceholder]
// 3
    // grab elements in console and then paste code
    // write event listener
    // do dom manipulation not including mark as done
    // use debugger in add item
    // talk about prevent default
// 4
/////////////////////////

//grab the dom elements we need (groceries, grocery-form, recipe-list, recipes)
const groceries = document.querySelector(".groceries");
const groceryForm = document.querySelector(".grocery-form");
const recipeList = document.querySelector(".recipe-list");
const recipes = document.querySelector(".recipes"); //finds first instance of this class

//create variables to hold localStorage things
//NO NEED TO REMOVE PRIOR TO DEMO!!!
const lsItems = JSON.parse(localStorage.getItem('items')) || [];
const lsRecipes = JSON.parse(localStorage.getItem('recipes')) || [];

//---------------PHASE 1 DOM MANIPULATION DEMO-----------------//
//create event handler that adds to our grocery list
const addItem = (e) => {
    // ***Write event listener first***
    e.preventDefault();

    // grab input field and extract its value
    // let input = document.querySelector("input[name='add-grocery']"); 
    let input = groceryForm.firstElementChild
    // returns first element that matches
    // DEMO on console properties available on HTMLElement
    // ----
    // demo in console how to get that element, change its value, change its placeholder, etc
    // ----
    let value = input.value;
    
    // create an item object
    // EXPLAIN that in js you can pass in 1 value and will set key and value
    const item = { value }; // {value:"cheese"}
    // THROW DEBUGGER HERE
    // add to our list of localStorage items
    lsItems.push(item);
    localStorage.setItem("items", JSON.stringify(lsItems));
    // DEMO on console how our lsItems look like
    // PUT DEBUGGER HERE
    // call our method to update grocery list to show new item
    updateList();

    // clear input fields (reset is a method on forms that clears the form)
    groceryForm.reset();
    
}

//create action to render grocery list items
const updateList = () => {

    // method 1: using string html element
    // map over lsItems, return string interpolated li item
    // add as list item to our groceries.innerHTML
    // DEMO how it looks in elements without join(" ")
    groceries.innerHTML = lsItems.map((item) => {
        return `<li>${item.value}</li>`
    }).join(" "); 

   
    // method 2: using document.createElement
        // map over lsItems, create li elemtn, add innerText to li, then appendChild
        // createElement returns an html element
        // append vs appendChild 
            // -> appendChild returns the appended node object whereas append has no return value
            // -> you can append multiple items (nodes or strings) with append
    // if (!groceries.hasChildNodes()) {
    //     lsItems.map((item) => {
    //         let li = document.createElement("li");
    //         li.innerText = item.value;
    //         groceries.appendChild(li);
    //     });
    // } else {
    //     let li = document.createElement("li")
    //     li.innerText = lsItems[lsItems.length - 1].value;
    //     groceries.appendChild(li);
    // }

}
// DO IN PHASE 2
//create event handler to cross out list items on click
const markAsDone = (e) => {
    e.stopPropagation(); //DEMO with/without this during phase III

    // On click, grab e.target and save into variable NOT currentTarget 
        // bc we want the li that triggered it
    let clicked = e.target;

    // use child.classList which returns a collection of class attributes
    // call .toggle method on it to add class if it's not there, remove if it is
    // show classList in console?
    clicked.classList.toggle('done');
}
// DO IN PHASE 2

//---------------PHASE III FOR WINDOW, LOCATION, HISTORY DEMO-----------------//

//NO NEED TO REMOVE PRIOR TO DEMO!!!
//create event handler that adds to our recipes list
const addRecipe = (e) => {
    e.preventDefault();

    // grab the target's innerText that was clicked on 
    let recipeText = e.target.innerText;

    // add to our list of localStorage items
    lsRecipes.push({ recipeText });
    localStorage.setItem("recipes", JSON.stringify(lsRecipes))

    // call our method to update recipe list to show new item
    updateWeeklyRecipe();
}

//NO NEED TO REMOVE PRIOR TO DEMO!!!
//create action to render our recipes list
const updateWeeklyRecipe = () => {
    // map over lsRecipes, create a tags with createElement, set href = "", add innerText to li, 
        // add "recipeText" class to a tag, then appendChild to recipes
    recipes.innerHTML = lsRecipes.map((recipe) => {
        return `
            <a href="" class="recipeText">
                ${recipe.recipeText}
            </a>
            `
    });
// DEMO SOME OF THE  HISTORY COMMANDS FIRST
//WRITE EVENT LISTENER IN DEMO to set window.location.hash
    // also add event listener to recipes for on click, grab text from innerText, then set hash to text
    recipes.addEventListener("click", (e) => {
        // DEMO what happens when forget to prevent default
        e.preventDefault();
        let text = e.target.innerText;
        window.location.hash = text.trim() //trims empty spaces on each side of text;
    })
}

//---------------------------------------------------------------------//

//add event listener to on submit for form to process add item
groceryForm.addEventListener("submit", addItem);

//add event listener to cross out a list item
//we put event handler on parent to utilize event delegation
//COMMENT OUT WHEN DEMO-ING EVENT BUBBLING
groceries.addEventListener("click", markAsDone);

//add event listener to to add recipe
//we put event handler on parent to utilize event delegation
recipeList.addEventListener("click", addRecipe);

//call our methods to populate DOM
updateList();
updateWeeklyRecipe();

//--------------------PHASE II EVENT BUBBLIING DEMO---------------------------------//

//NO NEED TO REMOVE PRIOR TO DEMO!!!
//COMMENT IN TO SHOW UNINTENDED SIDE EFFECTS OF EVENT BUBBLING
// let groc = document.querySelectorAll(".groceries li") //select the li's
// groc.forEach((child) => {
//     child.addEventListener("click", markAsDone);
// })
// const boo = (e) => {
//     alert("Boo from the groceries ul! You didn't expect this, did you?!")
// }
// const doc = (e) => {
//     alert("Boo from the TOP of the document! You didn't expect this, did you?!")
// }

//COMMENT IN TO SHOW UNINTENDED SIDE EFFECTS OF EVENT BUBBLING
// groceries.addEventListener("click", boo); //parent
// document.addEventListener("click", doc); //parent

//---------------------------------------------------------------------//

//Script to demo LinkedIn endorsements for beginning of lecture
// let skills = document.getElementsByClassName('pv-skill-entity__featured-endorse-button-shared');
// for (let i = 0; i < skills.length; ++i) {
//     skills[i].click();
// }

// let headsArr = Array.from(document.getElementsByTagName('h3'))
// headsArr.forEach(thing => {
//     thing.innerText = 'javascript good';
//     thing.style.color = 'red';
//     thing.style.fontFamily = 'comic-sans'
// })
// let aTagsArr = Array.from(document.getElementsByTagName('a'))
// aTagsArr.forEach(ele => {
//     ele.href = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'
// })


