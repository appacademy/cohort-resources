dropdb lecture
createdb lecture
psql lecture < setup_lecture_db.sql
